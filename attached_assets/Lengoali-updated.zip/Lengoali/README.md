# Lengoali 🌐

A language-learning platform that lets you paste any text, click words to translate them, save vocabulary, and practice with flashcards and quizzes.

## Features

- **Interactive reader** — click any word to see translations, part of speech, pronunciation, synonyms & emoji
- **35+ languages** supported via Google Translate
- **Word colorization** by part of speech (noun, verb, adjective, etc.)
- **Saved words** with search, filter, sort, custom notes & example sentences
- **Flashcard mode** with shuffle
- **Quiz mode** — typing, multiple choice, or reverse; with streak & daily goal tracking
- **Text-to-speech** via Web Speech API + Google Audio fallback
- **5 UI languages**: English, Arabic, Finnish, Spanish, French
- **Dark / light theme**
- **Adjustable reader font size** and TTS speed

## Getting Started

```bash
npm install
npm run dev
```

Then open http://localhost:5173

## Build for Production

```bash
npm run build
```

Output is in the `dist/` directory.

## No Backend Required

This app is 100% frontend. All translations are fetched directly from the free Google Translate API endpoint.
