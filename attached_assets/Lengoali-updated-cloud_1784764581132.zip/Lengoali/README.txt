Lengoali — Multilingual Reading & Translation App
  ====================================================
  Generated: 2026-04-27T04:23:29.580Z

  Files in this archive:
  - src/App.tsx       Main React component (full app, ~3000 lines)
  - src/main.tsx      React entry point
  - src/index.css     Base styles
  - index.html        HTML shell (Vite)
  - package.json      Dependencies (react, lucide-react, vite, typescript)
  - tsconfig.json     TypeScript config
  - vite.config.ts    Vite config

  Quick start:
    pnpm install
    pnpm run dev

  Features:
    • Reader with auto-detect, word translation, POS colorize
    • Saved words: edit translation, add note, example sentence + per-language
      sentence translation, search, filter (All/Review/Edited), sort
    • Quiz: 3 modes (type/multi-choice/reverse), word-count selector,
      hint, skip, progress bar, ignore Arabic diacritics, mark-as-correct,
      spaced-repetition weighting, optional sound, end celebration
    • Flashcards with shuffle
    • Streak counter and daily goal in header
    • Confetti + ✅ on correct, shake + 😢 on wrong, full-screen 🏆 + confetti at end
    • 5 UI languages (en/ar/fi/es/fr), ~38 translation languages
  